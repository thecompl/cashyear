import 'package:flutter/material.dart';
class ConstStr{

  static const String app_name = "CityTimes";
  static const String savepre = "Save your Preferences";
  static const String sign_in = "Sign in";
  static const String noti = "Notification";
  static const String nightmode = "Night Mode";
  static const String fontsize = "Font Size";
  static const String lang = "Language";
  static const String about = "About Us";
  static const String contact = "Contact Us";
  static const String policy = "Privacy Policy";
  static const String categories = "Categories";
  static const String fb = "Facebook";
  static const String signupfb = "Sign in with Facebook";
  static const String signugoogle = "Sign in with google";
  static const String signuphone = "Sign in with Phone";
  static const String like = "Like";
  static const String bookmark = "Bookmarked";
  static const String share = "share";

}