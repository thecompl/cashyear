package com.example.citytimes

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
